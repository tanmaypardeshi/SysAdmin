#!/bin/bash

sudo rm -rf /home/$USER/SysAdmin


